24C32-64
========

Arduino library for 24C32/64 serial EEPROM
